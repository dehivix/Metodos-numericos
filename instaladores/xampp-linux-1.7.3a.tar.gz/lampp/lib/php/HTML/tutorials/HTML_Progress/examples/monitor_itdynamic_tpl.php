<?php
header('Content-type: text/plain');
echo file_get_contents('monitor_itdynamic.html');
?>